package com.zainul.medichapp.gelembung

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zainul.medichapp.R


class Activitymaps : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activitymaps)

    }
}
