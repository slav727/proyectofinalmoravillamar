# Medich-App
Medich is an application that raises the problem of satisfaction related to BPJS, especially in the lower classes, with Medich being able to solve all these problems. Medich has a Donation feature that will be very useful for the Community


# Application Overview
![readme image](https://user-images.githubusercontent.com/92244055/201970949-afd0c996-932d-4e88-a53a-42344dac4b55.png)

# Tools
- Android Studio
- Firebase ( Autenthication )
- 100% Kotlin
- Spotify ( For enjoy )

# How to Use 
- Copy from code clone in HTTPS
- Go to Android Studio 
- Clone from Git
- Paste Link 
- Done

# Whats is needed
- Gradle 7.4 Version ( Up To Date )
- Firebase Auth
- Api 29 Min
- SDK

# Includes
- Login Firebase Auth
- Geo location
